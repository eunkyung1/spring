package com.java.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring122601ApplicationTests {

	@Test
	void contextLoads() {
	}

}
