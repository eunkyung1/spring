package com.java.www;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring122601Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring122601Application.class, args);
	}

}
