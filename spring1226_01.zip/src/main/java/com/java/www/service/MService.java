package com.java.www.service;

import com.java.www.dto.MemberDto;

public interface MService {

	int login(MemberDto mdto);

}
